-- Create the DR database comment

COMMENT ON DATABASE disaster_recovery
    IS 'Disaster Recovery database.';
