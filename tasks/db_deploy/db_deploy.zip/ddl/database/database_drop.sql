-- Drops the DR database
DROP DATABASE IF EXISTS disaster_recovery;
